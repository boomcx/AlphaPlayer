package com.ss.ugc.android.alpha_player.model

/**
 * created by dengzhuoyao on 2020/07/07
 */
class VideoInfo(val videoWidth: Int, val videoHeight: Int) {
}